package com.example.demo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class demo19 {
    public static void main(String[] args) {
        int[] gas = {5, 1, 2, 3, 4};
//        int[] cost= {4,4,1,5,1};
//        int bal = 0;
//        int index = -1;
//        int def = 0;
//        for(int i = 0; i < gas.length; i++){
//            bal += gas[i] - cost[i];
//            if(bal <= 0){
//                def += bal;
//                bal = 0;
//                index = i+1;
//            }
//            if(bal > def){
//                System.out.println(index);
//                break;
//            }
//        }
//        System.out.print(-1);
//    }
        List<Person> list = new ArrayList<>();
        list.add(new Person("ABC", 9000));
        list.stream().filter(s->s.getSalary() > 8000 && s.getSalary() < 15000).collect(Collectors.groupingBy(s-> s.getName(), Collectors.maxBy(Comparator.comparingInt(Person::getSalary))));
    }
}


class Person{
    String name;
    int salary;

    public Person(String name, int salary) {
        this.name = name;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }
}
