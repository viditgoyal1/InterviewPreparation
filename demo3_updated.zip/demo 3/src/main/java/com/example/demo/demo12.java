package com.example.demo;

import java.util.*;

public class demo12 {
    int id;
    String name;


    public demo12(int id, String name) {
        this.id = id;
        this.name = name;
    }
    public static void main(String args[]){
        Map<demo12, Integer> map = new HashMap<demo12, Integer>();

        demo12 s1 = new demo12(11,"John");
        demo12 s2 = new demo12(22,"Eric");
        map.put(s1, 100);
        map.put(s2, 200);



        //what will be size of map
        System.out.println(map);

    }

    @Override
    public int hashCode() {
        return 1;
    }

    @Override
    public boolean equals(Object obj) {
        return true;
    }

    @Override
    public String toString() {
        return "demo12{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }
    //        String[][] marks = new String[][] {{"Bobby", "87"},{"Bobby", "88"},{"Bobby", "87"},{"Bobby", "89"},
//                {"Charles", "100"}, {"Eric", "64"}, {"Charles", "22"}};
//        int a = bestAverageGrade(marks);
//        System.out.println(a);


    public static int bestAverageGrade(String[][] scores) {
        Map<String, List<Integer>> map = new HashMap();
        for(int i = 0; i < scores.length; i++){
            if(map.containsKey(scores[i][0])){
                List<Integer> list = map.get(scores[i][0]);
                list.add(Integer.parseInt(scores[i][1]));
                map.put(scores[i][0], list);
            }
            else{
                List<Integer> list = new ArrayList<>();
                list.add(Integer.parseInt(scores[i][1]));
                map.put(scores[i][0], list);
            }
        }

        List<Integer> mainList = new ArrayList<>();
        for(Map.Entry<String, List<Integer>> entry : map.entrySet()){
            List<Integer> list = entry.getValue();
            int sum = 0;
            for(int i = 0; i < list.size(); i++){
                sum += list.get(i);
            }
            sum = sum/list.size();
            mainList.add(sum);
        }
        Collections.sort(mainList);
        return mainList.get(mainList.size()-1);
    }
}
