package com.example.demo;

import java.util.HashSet;
import java.util.Set;

public class demo23 {
	public static void main(String args[]) {
//		int arr[] = {1,2,3,4,6,7};
//		for(int i = 0; i < arr.length; i++){
//			if(arr[i] != i+1){
//				System.out.print(i);
//				break;
//			}
//		}
		
		//Size of smallest unique substring
		String str = "abaaba";
		
		int left = 0;
		int right = 0;
		int max = Integer.MIN_VALUE;
		Set<Character> set = new HashSet<>();
		while(right < str.length()) {
			while(set.contains(str.charAt(right))) {
				set.remove(str.charAt(left));
				left++;
			}
			max = Math.max(max,  right-left + 1);
			set.add(str.charAt(right));
			right++;
		}
		System.out.print(max);
	}
}
