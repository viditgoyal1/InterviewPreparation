package com.example.demo;

public class demo13 {
    public static void main(String args[]){
        String str = "sabcbas";
        int count = 0;
        String s1 = "";
        int max = 0;
        for(int i = 0; i < str.length(); i++){
            for(int j = i+1; j < str.length()+1; j++){
                String s = str.substring(i,j);
                if(palindrome(s)){
                    count = s.length();
                    if(max < count){
                        max = count;
                        s1 = s;
                    }
                }

            }
        }
        System.out.println(s1);
        System.out.println(max);
    }
    public static boolean palindrome(String str){
        int left = 0;
        int right = str.length()-1;
        while(left < right){
            if(str.charAt(left) == str.charAt(right)){
                left++;
                right--;
            }
            else{
                return false;
            }
        }
        return true;
    }
}
