package com.example.demo;

public class demo20 {
    public static void main(String[] args) {
        int[] arr = {2,4,6,0,12};
        int start = 0;
        int end = 4;
        int total = 0;
        int i = start+1;
        while(start < end && i <= end){
            if(arr[start] < arr[i]){
                total += arr[start]*(i-start);
                start = i;
            }
            i++;
        }
        System.out.print(total);

    }
}
