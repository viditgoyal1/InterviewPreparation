package com.example.demo;

public class demo21 {
    public static void main(String[] args) {

    }
}
