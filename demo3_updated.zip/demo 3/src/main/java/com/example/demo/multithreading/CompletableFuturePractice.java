package com.example.demo.multithreading;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class CompletableFuturePractice {
    public static void main(String[] args) {
        CompletableFuture.supplyAsync(()-> "Hello")
                .thenApply(a -> a + " World")
                .thenAccept(a -> System.out.print(a));


        // Join the results of 4 tasks using completable future
        CompletableFuture<Integer> cf1 = CompletableFuture.supplyAsync(() -> 1);
        CompletableFuture<Integer> cf2 = CompletableFuture.supplyAsync(() -> 2);
        CompletableFuture<Integer> cf3 = CompletableFuture.supplyAsync(() -> 3);
        CompletableFuture<Integer> cf4 = CompletableFuture.supplyAsync(() -> 4);
        CompletableFuture<Void> all = CompletableFuture.allOf(cf1, cf2, cf3, cf4);
        all.thenRun(()->{
            try {
                Integer result1 = cf1.get();
                Integer result2 = cf2.get();
                Integer result3 = cf3.get();
                Integer result4 = cf4.get();

                System.out.println("Results:");
                System.out.println(result1);
                System.out.println(result2);
                System.out.println(result3);
                System.out.println(result4);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Combine the results of all the completable futures and print the final result.
        CompletableFuture<Integer> cf5 = cf1.thenCombine(cf2, (r1,r2) -> r1+r2).thenCombine(cf3, (r1,r2) -> r1+r2).thenCombine(cf4, (r1,r2) -> r1+r2);
        try {
            Integer result5 = cf5.get();
            System.out.println("Combined result : " + result5);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        }

    }
}
