package com.example.demo.multithreading;

public class ProducerConsumer {
    public static void main(String[] args) {
        PC pc = new PC();
        new Thread(() -> pc.producer()).start();
        new Thread(() -> pc.consumer()).start();
    }
}
class PC{
    int count = 0;
    volatile boolean isProduced = false;
    public synchronized void producer(){
        while(true){
            if(isProduced){
                try {
                    wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            count++;
            System.out.println("Produced : " + count);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            isProduced = true;
            notify();
        }
    }
    public synchronized void consumer(){
        while(true) {
            if(!isProduced){
                try {
                    wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            System.out.println("Consumed : " + count);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            isProduced = false;
            notify();
        }
    }
}
