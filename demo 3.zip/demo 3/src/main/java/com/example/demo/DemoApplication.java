package com.example.demo;

import com.example.demo.designPatterns.Car;
import com.example.demo.functionalInterface.MyFunctionalInterface;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);

		//Use Builder Pattern
		Car c = Car.CarBuilder.builder().setEngine("").setWheel("").build();

		//Funtional Interface implementation
		MyFunctionalInterface obj1 = () -> System.out.print("Overridden abstract method...");
		obj1.m1();
		MyFunctionalInterface.m2();
		obj1.m3();
	}
}
