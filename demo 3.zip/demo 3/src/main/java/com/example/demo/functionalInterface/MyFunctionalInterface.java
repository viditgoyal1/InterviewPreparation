package com.example.demo.functionalInterface;
@FunctionalInterface
public interface MyFunctionalInterface {
    public void m1();
    public static void m2(){
        System.out.print("Static Method");
    }
    public default void m3(){
        System.out.print("Default Method");
    }
}
