package com.example.demo;

import org.springframework.scheduling.annotation.Async;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;

public class demo15 {
    public  void get(){
        put();
        //
        //update()
    }
    public void put(){

    }
    public  void call(){
        get();
    }
    public static void main(String args[]) {

    }
}
