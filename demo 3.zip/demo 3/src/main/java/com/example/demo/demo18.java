package com.example.demo;

public class demo18 {
    public static void main(String[] args) {
        //Input: [>, <, <, >, >] Output: 2
        //Input: [>, <, >, >, <] Output: 4
        String str = "<,<,>,>,<";
        int count = 0;
        for(int i = 0; i < str.length(); i++){
            if(str.charAt(i) == '>'){
                for(int j = i+1; j < str.length(); j++){
                    if(str.charAt(j) == '<'){
                        count++;
                    }
                }
            }
        }
        System.out.println(count);
    }
}
