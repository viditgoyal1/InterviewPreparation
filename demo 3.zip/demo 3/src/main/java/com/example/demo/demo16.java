package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class demo16 {
    public static void main(String[] args) {
        int[][] prerequisite =  {{1,0},{2,0},{3,1}, {4,3}, {4,2}};
        //[1, 0], [2, 0], [3, 1], [4, 3], [4, 2]]
        int numCourses = 5;
        System.out.print(solve(numCourses, prerequisite));
    }
    public static boolean solve(int numCourses, int[][] prerequisite){
        Map<Integer, List<Integer>> map = new HashMap<>();
        boolean vis[] = new boolean[numCourses];
        for(int i = 0; i < prerequisite.length; i++){
            List<Integer> list = null;
            if(map.containsKey(prerequisite[i][0])){
                list = map.get(prerequisite[i][0]);
            }
            else{
                list = new ArrayList<>();
            }
            list.add(prerequisite[i][1]);
            map.put(prerequisite[i][0], list);
        }
        for(Map.Entry<Integer, List<Integer>> entry : map.entrySet()){
            List<Integer> list = entry.getValue();
            for(int i = 0; i < list.size(); i++){
                if(!map.containsKey(list.get(i))){
                    vis[list.get(i)] = true;
                }
            }
        }
        for(Map.Entry<Integer, List<Integer>> entry : map.entrySet()){
            List<Integer> list = entry.getValue();
            for(int i = 0; i < list.size(); i++){
                if(!vis[list.get(i)]){
                    return false;
                }
            }
            vis[entry.getKey()] = true;
        }
        return true;
    }
    //n*m
}
