package com.example.demo.basicconcepts;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class ConcurrentModificationExp {
    public static void main(String[] args) {
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);

        // Code for Concurrent Modification exception
        // It occurs because modification count changes when element is removed outside the iterator. When it.next() is called, it will check
        // if there is a mismatch in expectedModificationCount (in iterator) and modificationCount (in arraylist).
//        Iterator<Integer> it = list.iterator();
//        while(it.hasNext()){
//            Integer num = it.next();
//            if(num == 2){
//                list.remove(num);
//            }
//        }

        // Solution 1: Use remove() method of iterator.
//        Iterator<Integer> it1 = list.iterator();
//        while(it1.hasNext()){
//            Integer num = it1.next();
//            if(num == 2){
//                it1.remove();
//            }
//        }

        //Solution 2: Use CopyOnWriteArrayList
//        List<Integer> list1 = new CopyOnWriteArrayList<>();
//        list1.add(1);
//        list1.add(2);
//        list1.add(3);
//        list1.add(4);
//
//        Iterator<Integer> it = list1.iterator();
//        while(it.hasNext()){
//            Integer num = it.next();
//            if(num == 2){
//                list1.remove(num);
//            }
//        }

        // Solution 3: Use removeIf in Java8
        list.removeIf(element -> element.equals(2));  // Remove elements safely

        for(int i = 0; i < list.size(); i++){
            System.out.print(list.get(i));
        }
    }
}
