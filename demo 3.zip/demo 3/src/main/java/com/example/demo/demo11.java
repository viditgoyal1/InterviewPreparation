package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class demo11 {
    public static void main(String args[]){
        String str1 = "Drier".toLowerCase();
        String str2 = "Rider".toLowerCase();
        Map<Character, Integer> map1 = new HashMap<>();
        Map<Character, Integer> map2 = new HashMap<>();

        for(int i = 0; i < str1.length(); i++){
            map1.put(str1.charAt(i), map1.getOrDefault(str1.charAt(i), 0)+1);
        }
        for(int i = 0; i < str2.length(); i++){
            map2.put(str2.charAt(i), map2.getOrDefault(str2.charAt(i), 0)+1);
        }
        boolean val = checkAnagram(map1, map2);
        System.out.println(val);
    }
    public static boolean checkAnagram(Map<Character, Integer> map1, Map<Character, Integer> map2){
        for(Map.Entry entry : map1.entrySet()){
            if(!(map2.containsKey(entry.getKey()) && map2.get(entry.getKey()) == entry.getValue())){
                return false;
            }
        }
        return true;
    }
}
