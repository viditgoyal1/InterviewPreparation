package com.example.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Demo14 {
    public static void main(String args[]){
        int arr[] = {-3, 7, -1, -5, 2, -9, 1};
        // -9, -5, -3, -1, 1,2,7
        int target = 0;

        Arrays.sort(arr);
        List<String> list = new ArrayList<>();
        for(int i = 0; i < arr.length-2; i++){
            int left = i+1;
            int right = arr.length-1;
            while(left < right){
                int sum = arr[i] + arr[left] + arr[right];
                if(sum == 0){
                    list.add(arr[i]+", "+arr[left] +", "+ arr[right]);
                    left++;
                    right--;
                }
                else if(sum > 0){
                    right--;
                }
                else{
                    left++;
                }
            }
        }
        for(int i = 0; i < list.size(); i++){
            System.out.println(list.get(i));
        }
    }
}
