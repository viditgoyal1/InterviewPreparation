package com.example.demo;

public class demo22 {
	public static void main(String args[]) {
		// arr = 12345.   k = 2   rotate the array by K steps
		// 5671234
		int arr[] = {-1,-100,3,99};
		int k = 2;
		reverse(arr, 0, arr.length-1);
		reverse(arr, 0, k-1);
		reverse(arr, k, arr.length-1);
		for(int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}
	 
	public static void reverse(int arr[], int left, int right) {
		while(left < right) {
			int temp = arr[left];
			arr[left] = arr[right];
			arr[right] = temp;
			left++;
			right--;
		}
	}
}
