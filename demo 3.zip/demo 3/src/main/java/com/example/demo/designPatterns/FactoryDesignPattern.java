package com.example.demo.designPatterns;

interface I1{
    public void display();
}

class A1 implements I2 {
    public void display(){
        System.out.println("1");
    }
}
class A2 implements I2 {
    public void display(){
        System.out.println("2");
    }
}

public class FactoryDesignPattern {
    public static I2 getInstance(String s){
        if(s.equals("A1")){
            return new B1();
        }
        else{
            return new B2();
        }
    }
}
