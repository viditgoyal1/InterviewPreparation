package com.example.demo.designPatterns;

interface I2 {
    public void display();
}

class B1 implements I2 {
    public void display(){
        System.out.println("1");
    }
}
class B2 implements I2 {
    public void display(){
        System.out.println("2");
    }
}

class Context{
    public I2 i2;
    public Context(I2 i2){
        this.i2 = i2;
    }
    public void setContext(I2 i2){
        this.i2 = i2;
    }
    public void execute(){
        i2.display();
    }
}
public class StrategyDesignPattern {
    public static void main(String[] args) {
        Context i = new Context(new B1());
        i.execute();
        i.setContext(new B2());
        i.execute();
    }
}
