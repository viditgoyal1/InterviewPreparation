package com.example.demo;

public class demo17 {
    public static void main(String[] args) {
        int[][] intervals = {{1,2}, {3,5}, {6,7}, {8,10}, {12,16}};
        // [[1,2],[3,5],[6,7],[8,10],[12,16]],
        //Output: [[1,2],[3,10],[12,16]]
        int[] newIn = {4,8};
        solve(intervals, newIn);
        for(int i = 0; i < intervals.length; i++){
            System.out.println(intervals[i][0] +" "+ intervals[i][1]);
        }
    }
    public static void solve(int[][] intervals, int[] newInterval){
        int start = newInterval[0];
        int end = newInterval[1];
        for(int[] interval : intervals){
            if(interval[1] > start){
                interval[0] = Math.min(interval[0], start);
            }
            if(interval[1] < end){
                interval[1] = Math.max(interval[1], end);
            }
            break;
        }
    }
}
