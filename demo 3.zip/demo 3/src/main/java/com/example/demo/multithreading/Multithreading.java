package com.example.demo.multithreading;

public class Multithreading {
    public static void main(String[] args) {
        DeadLockPrevention example = new DeadLockPrevention();
        new Thread(()-> example.method1()).start();
        new Thread(()-> example.method2()).start();
    }

}
class DeadLockPrevention{
    private Object lock1 = new Object();
    private Object lock2 = new Object();
    public void method1() {
        synchronized(lock1){
            System.out.print("Lock1 acquired ...");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            synchronized(lock2){
                System.out.print("Lock2 acquired ...");
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
    public void method2(){
        synchronized(lock2){
            System.out.print("Lock2 acquired ...");
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            synchronized(lock1){
                System.out.print("Lock1 acquired ...");
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
