package com.example.demo.DSA;

public class RotateArray {
    public static void main(String args[]){
        int arr[] = {4,1,8,3,6,5};
        int pos = 2;
        reverse(arr, 0, arr.length-1);
        reverse(arr, 0, arr.length-pos-1);
        reverse(arr, arr.length-pos, arr.length-1);
        for(int i = 0; i < arr.length; i++){
            System.out.print(arr[i]);
        }
    }
    public static void reverse(int nums[], int left, int right){
        while(left < right){
            int temp = nums[left];
            nums[left] = nums[right];
            nums[right] = temp;
            left++;
            right--;
        }
    }
}
