package com.example.demo.multithreading;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorServicePractice {
    public static void main(String[] args) {
        ExecutorService fixed = Executors.newFixedThreadPool(3);
        for(int i = 0; i < 5; i++){
            fixed.submit(()->{
                System.out.println("Hello");
            });
        }
        fixed.shutdown();
    }
}
