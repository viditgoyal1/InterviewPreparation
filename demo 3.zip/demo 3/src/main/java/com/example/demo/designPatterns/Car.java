package com.example.demo.designPatterns;

//Builder Design Pattern
public class Car {
    private String wheel = null;
    private String engine = null;

    private Car(CarBuilder carBuilder){
        this.wheel = carBuilder.wheel;
        this.engine = carBuilder.engine;
    }
    public static class CarBuilder{
        private String wheel = null;
        private String engine = null;

        public static CarBuilder builder(){
            return new CarBuilder();
        }
        public CarBuilder setWheel(String wheel){
            this.wheel = wheel;
            return this;
        }
        public CarBuilder setEngine(String engine){
            this.engine = engine;
            return this;
        }

        public Car build(){
            return new Car(this);
        }
    }
}
