package com.example.demo.optional;

import java.util.Optional;

public class Practice {
    class Employee{
        private String name;
        public String getName(){
            return name;
        }
    }
    public static void main(String[] args) {
        getEmployeeName(null);
    }
    public static String getEmployeeName(Employee employee) {
        return Optional.ofNullable(employee)
                .map(Employee::getName)
                .map(String::toUpperCase)
                .orElse("Unknown");
    }
}
