package com.example.demo;

import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

class Employee{
    private String name;
    private int age;

    public Employee(String name, int age){
        this.name = name;
        this.age = age;
    }
    public String getName(){
        return name;
    }
    public int getAge(){
        return age;
    }
}
public class Streams {

    public static void main(String[] args) {
        List<Employee> list = Arrays.asList(
                new Employee("abc", 1),
                new Employee("xyz", 2)
        );
        list.stream().mapToInt(s->s.getAge()).average();
        // Stream questions
        Map<Integer, List<Employee>> map0 =  list.stream().collect(Collectors.groupingBy(Employee::getAge));
        Map<String, Optional<Employee>> map =  list.stream().collect(Collectors.groupingBy(Employee::getName, Collectors.maxBy(Comparator.comparingInt(Employee::getAge))));
        Map<String, Optional<Employee>> map1 =  list.stream().collect(Collectors.groupingBy(Employee::getName, Collectors.minBy(Comparator.comparingInt(Employee::getAge))));
        Map<String, Integer> map2 =  list.stream().collect(Collectors.groupingBy(Employee::getName, Collectors.summingInt(Employee::getAge)));
        Map<String, Double> map3 =  list.stream().collect(Collectors.groupingBy(Employee::getName, Collectors.averagingInt(Employee::getAge)));
        Map<String, String> map4 =  list.stream().collect(Collectors.groupingBy(Employee::getName, Collectors.mapping(Employee::getName, Collectors.joining(", "))));
        Map<String, List<String>> map5 =  list.stream().collect(Collectors.groupingBy(Employee::getName, Collectors.mapping(Employee::getName, Collectors.toList())));

        //FlatMap
        List<List<Integer>> listOfLists = List.of(
                List.of(1, 2, 3),
                List.of(4, 5),
                List.of(6, 7, 8)
        );
        List<Integer> list1 = listOfLists.stream().flatMap(list2->list2.stream()).collect(Collectors.toList());

        // Using streams, Convert the list into single string and reverse the numbers, if present.
        List<String> list2 = Arrays.asList("abc123", "jkl456", "mno");
        String str = list2.stream().map(s-> manipulateString(s)).collect(Collectors.joining(", "));
        //System.out.println(str);

        // Find first duplicate number
        List<Integer> list3 = Arrays.asList(1,2,3,1,3,5,6,7);
        Integer i = list3.stream().collect(Collectors.groupingBy(e-> e, LinkedHashMap::new, Collectors.counting()))
                .entrySet().stream()
                .filter(e->e.getValue() > 1)
                .map(e->e.getKey())
                .findFirst()
                .orElse(null);
        //System.out.println(i);

        // find occurrences of each character.
        String str1 = "abcd";
        Map<Character, Long> map6 = str.chars().mapToObj(c->(char)c).collect(Collectors.groupingBy(e -> e, Collectors.counting()));




        List<Integer> list11 = Arrays.asList(1,2,3,4,5);
        //Filter and collect even numbers
        List<Integer> list12 = list11.stream().filter(s->s%2==0).collect(Collectors.toList());
        list12.forEach(System.out::println);
        // Convert a list of strings to uppercase
        List<String> list13 = Arrays.asList("a","b","asd");
        List<String> list14  = list13.stream().map(s->s.toUpperCase()).collect(Collectors.toList());
        list14.forEach(System.out::println);
        //     Filter employees by department
        List<Employee1> employees = Arrays.asList(new Employee1("vidit", "IT", 1000), new Employee1("abc", "AN", 1000), new Employee1("xyz", "yy", 2000));
        Set<Employee1> employees1 = employees.stream().filter(s->s.getDept().equals("IT")).collect(Collectors.toSet());
        employees1.forEach(System.out::println);


        //Calculate the sum of numbers
        Integer a = list11.stream().mapToInt(s->(int)s).sum();
        System.out.println(a);
        //Find the average salary of employees
        OptionalDouble b = employees.stream().map(s->s.getSalary()).mapToInt(s->(int)s).average();
        System.out.println(b);
         //       Count occurrences of words
        List<String> list15 = Arrays.asList("abc","abb","abc","xyz");
        Map<String, Long> map7 = list15.stream().collect(Collectors.groupingBy(s->s, Collectors.counting()));


        //Sort a list of employees by age
        //just use age instead of salary
        List<Employee1> list0 = employees.stream().sorted(Comparator.comparingInt(s->s.getSalary())).collect(Collectors.toList());
        //Group employees by department
        employees.stream().collect(Collectors.groupingBy(Employee1::getDept));
        // Find the highest-paid employee in each department
        employees.stream().collect(Collectors.groupingBy(Employee1::getDept, Collectors.maxBy(Comparator.comparingInt(Employee1::getSalary))));


        //Flat map a list of lists
        listOfLists.stream().flatMap(s->s.stream()).collect(Collectors.toList());
        // Find duplicate elements
        List<Integer> list16 = Arrays.asList(1,1,3,3,4,5);
        list16.stream().collect(Collectors.groupingBy(s->s, Collectors.counting()))
                .entrySet().stream()
                .filter(s->s.getValue() > 1)
                .map(s->s.getKey())
                .collect(Collectors.toList());
        //Partition employees by salary
        Map<Boolean, List<Employee1>> employeePartitions = employees.stream().collect(Collectors.partitioningBy(s->s.getSalary()>1000));

        //Use parallel streams for a large dataset
        list16.parallelStream().mapToInt(s->s*s).sum();
        //Performance comparison
        //Compare the performance of a stream and a parallel stream for a task that involves summing a large number of integers.
        list16.parallelStream().mapToInt(s->s).sum();
        list16.stream().mapToInt(s->s).sum();

//        Filter, map, and sort in one pipeline
//        Given a list of integers, filter out odd numbers, multiply the even numbers by 2, and sort the resulting list.
          list16.stream().filter(s->s%2 == 0).map(s->s*2).sorted().collect(Collectors.toList());
//        Complex transformation
//        Given a list of Employee objects, filter those with a salary greater than 50,000, extract their names, and collect them into a comma-separated string.
          employees.stream().filter(s->s.getSalary() > 50000).map(Employee1::getName).collect(Collectors.joining(", "));

//        Find the first matching element
//        Given a list of integers, find the first even number. If no even number is found, return -1.
            list16.stream().filter(s -> s%2 == 0).findFirst().orElse(-1);
//        Safely extract optional values
//        Use streams to safely process and extract values from a list of Optional<Integer>.
        //list16.stream().map(s->s.get()).collect(Collectors.toList());

//        Merge two lists
//        Given two lists of integers, merge them into a single sorted list without duplicates.
            List<Integer> list17 = Arrays.asList(1,2,3,5,7,8);
        List<Integer> list18 = Arrays.asList(1,7,3,15,17,10,8);
        Stream.concat(
                list17.stream(),list18.stream()
        ).sorted().distinct().collect(Collectors.toList());

        // list {1,2,3,4,5,6} , we want to return the map {1,2},{3,4}, {5,6} using java steam?
        List<Integer> list19 = Arrays.asList(1,2,3,4,5,6);
        Map<Integer, Integer> map19 = IntStream.range(0, list19.size()/2).boxed().collect(Collectors.toMap(
                s-> list19.get(s*2),
                s-> list19.get(s*2 + 1)
        ));
        System.out.println(map19);
        // For practicing Java streams, refer - https://javaconceptoftheday.com/java-8-interview-sample-coding-questions/

        //Sort list of strings in increasing order of their length
        List<String> list20 = Arrays.asList("aa", "bbb", "hxubxuj", "oputd");
        List<String> listResult =  list20.stream().sorted(Comparator.comparingInt(String::length)).collect(Collectors.toList());
        System.out.println(listResult);

        //Sum of list elements
        Integer num = list19.stream().collect(Collectors.summingInt(s->s));
        System.out.println(num);

        //Reverse all elements in array
        int arr[] = {1,2,3,4,5,6};
        int res[] = IntStream.range(0, arr.length).map(s-> arr[arr.length-s-1]).toArray();
        for(int x = 0; x < arr.length; x++){
            System.out.println(res[x]);
        }

        //Palindrome program using stream
        boolean bool = IntStream.range(0, arr.length/2).noneMatch(s-> arr[s] != arr[arr.length-s-1]);
        System.out.println(bool);

        //Return last element of an array
        Integer op = Arrays.stream(arr).skip(arr.length-1).findFirst().orElse(0);
        System.out.println(op);

        //Map every two consecutive elements with each other
        List<Integer> list21 = Arrays.asList(1,2,3,4,5,6,7,8);
        IntStream.range(0,list.size()/2).boxed().collect(Collectors.toMap(
                iv -> list21.get(iv * 2),
                iv -> list21.get(iv * 2 + 1)
        ));

        //Max and min in a list
        list21.stream().max(Comparator.naturalOrder()).get();

        //Three min and max numbers in a list
        list21.stream().sorted(Comparator.reverseOrder()).limit(3);

        //Sum of digits of all numbers
        int num1 = 123456;
        Integer res1 = Stream.of(String.valueOf(num1).split("")).mapToInt(s->Integer.parseInt(s)).sum();
        System.out.println(res1);


        //Reverse each word of String
        String str2 = "Vidit is very intelligent boy";
        String res3 = Stream.of(str2.split(" ")).map(s->new StringBuilder(s).reverse()).collect(Collectors.joining(" "));
        System.out.println(res3);

        //Reverse an integer array
        int[] inputArr = {1,2,3,4,5,6};
        IntStream.range(0, inputArr.length).map(s-> inputArr[inputArr.length-1]).toArray();


        List<String> list25 = Arrays.asList("Alice", "Adam", "Bob", "Baam", "Cal", "Callabc");
        Map<Character, List<String>> map26 = list25.stream().collect(Collectors.groupingBy(s-> s.charAt(0)));
        for(Map.Entry<Character, List<String>> entry : map26.entrySet()){
            System.out.println(entry.getKey() +" " + entry.getValue());
        }

    }
    public static String manipulateString(String s){
        String letters = s.replaceAll("\\d","");
        String digits = s.replaceAll("\\D","");
        String reverseDigits = new StringBuilder(digits).reverse().toString();
        return letters + reverseDigits;
    }
}
class Employee1{
    private String name;
    private String dept;

    private Integer salary;


    public Employee1(String name, String dept, Integer salary){
        this.name = name;
        this.dept = dept;
        this.salary = salary;
    }
    public String getName(){
        return this.name;
    }
    public String getDept(){
        return this.dept;
    }
    public Integer getSalary(){
        return this.salary;
    }
}
